from sklearn.linear_model import LinearRegression
import numpy as np
import pandas as pd


def train_model(data):
    # Подготовка данных
    X = data[['deviceid', 'direction', 'segment', 'length']]
    y = data['run_time_in_seconds']

    # Создание и обучение модели
    model = LinearRegression()
    model.fit(X, y)

    return model


def make_prediction(model, deviceid, direction, segment, length):
    # Подготовка входных данных для предсказания
    input_data = np.array([[deviceid, direction, segment, length]])
    prediction = model.predict(input_data)
    return prediction[0]
