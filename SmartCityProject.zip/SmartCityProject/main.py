import tkinter as tk
from tkinter import messagebox
from datetime import datetime, timedelta
from src.data_processing import load_and_process_data
from src.model import train_model, make_prediction

class TransportAIApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Прогноз времени прибытия транспорта")

        # Загрузка данных и обучение модели
        self.data = load_and_process_data("public_transport_data.csv")
        if self.data is not None:
            self.model = train_model(self.data)

        # Создание интерфейса
        self.create_widgets()

    def create_widgets(self):
        # Поля ввода
        tk.Label(self.root, text="Device ID:").grid(row=0, column=0)
        self.deviceid_entry = tk.Entry(self.root)
        self.deviceid_entry.grid(row=0, column=1)

        tk.Label(self.root, text="Direction:").grid(row=1, column=0)
        self.direction_entry = tk.Entry(self.root)
        self.direction_entry.grid(row=1, column=1)

        tk.Label(self.root, text="Segment:").grid(row=2, column=0)
        self.segment_entry = tk.Entry(self.root)
        self.segment_entry.grid(row=2, column=1)

        tk.Label(self.root, text="Length:").grid(row=3, column=0)
        self.length_entry = tk.Entry(self.root)
        self.length_entry.grid(row=3, column=1)

        # Кнопка для предсказания
        self.predict_button = tk.Button(self.root, text="Сделать прогноз", command=self.make_prediction)
        self.predict_button.grid(row=4, column=0, columnspan=2)

    def make_prediction(self):
        try:
            # Получаем данные из полей ввода
            deviceid = float(self.deviceid_entry.get())
            direction = float(self.direction_entry.get())
            segment = float(self.segment_entry.get())
            length = float(self.length_entry.get())

            # Выполняем предсказание времени в секундах
            predicted_seconds = make_prediction(self.model, deviceid, direction, segment, length)

            # Текущее время
            current_time = datetime.now()

            # Рассчитываем время прибытия
            arrival_time = current_time + timedelta(seconds=predicted_seconds)

            # Форматируем вывод
            formatted_arrival_time = arrival_time.strftime('%H:%M')

            # Отображаем результат
            messagebox.showinfo("Результат", f"Прогнозируемое время прибытия: {formatted_arrival_time} (текущее время: {current_time.strftime('%H:%M')})")
        except ValueError:
            messagebox.showerror("Ошибка ввода", "Пожалуйста, введите числовые значения.")

if __name__ == "__main__":
    root = tk.Tk()
    app = TransportAIApp(root)
    root.mainloop()
